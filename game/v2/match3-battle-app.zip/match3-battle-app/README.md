# 多人实时对战消消乐 App

一个基于 WebSocket 的实时多人对战消消乐游戏应用。

## 功能特性

### 🎮 核心玩法
- **标准三消逻辑**：交换相邻宝石，消除三个或以上相同颜色的宝石
- **自动掉落填充**：消除后自动填充新宝石
- **连锁消除**：支持连续消除计分
- **8x8 游戏棋盘**：6 种不同颜色的宝石

### 🌐 联机对战
- **1v1 实时对战**：通过 WebSocket 实时同步游戏状态
- **60秒倒计时**：限时对战模式
- **实时分数显示**：查看自己和对手的实时得分
- **胜负判定**：游戏结束后自动判定胜负

### 🏠 房间系统
- **创建房间**：生成 6 位房间号，邀请好友加入
- **加入房间**：输入房间号加入指定房间
- **随机匹配**：自动匹配在线玩家

### 💬 即时通讯
- **文字聊天**：房间内实时文字交流
- **快捷表情**：7 个常用表情包快速发送
- **消息气泡**：区分自己和对手的消息

## 技术栈

### 后端
- **Node.js**：运行时环境
- **Express**：Web 框架
- **WebSocket (ws)**：实时通信

### 前端
- **原生 HTML/CSS/JavaScript**：无框架依赖
- **WebSocket API**：客户端实时通信
- **响应式设计**：适配移动设备

## 安装和运行

### 前置要求
- Node.js 14.0 或更高版本
- npm 或 yarn

### 安装步骤

1. **安装服务器依赖**
```bash
cd server
npm install
```

2. **启动服务器**
```bash
npm start
```

服务器将在 `http://localhost:3000` 启动。

3. **访问应用**

在浏览器中打开 `http://localhost:3000` 即可开始游戏。

### 开发模式

使用 nodemon 进行热重载开发：

```bash
cd server
npm run dev
```

## 项目结构

```
match3-battle-app/
├── server/
│   ├── server.js          # 服务器主文件
│   └── package.json       # 服务器依赖配置
├── client/
│   ├── index.html         # 主页面
│   └── game.js           # 游戏逻辑和 WebSocket 客户端
└── README.md             # 项目文档
```

## 游戏玩法

### 创建房间模式
1. 点击「创建房间」
2. 输入昵称
3. 获取 6 位房间号
4. 分享房间号给好友
5. 等待好友加入
6. 房主点击「开始游戏」

### 加入房间模式
1. 点击「加入房间」
2. 输入房间号和昵称
3. 等待房主开始游戏

### 随机匹配模式
1. 点击「随机匹配」
2. 系统自动生成昵称
3. 等待系统匹配对手
4. 匹配成功后自动进入房间

### 游戏规则
- **消除规则**：点击选择一个宝石，再点击相邻的宝石进行交换
- **有效消除**：横向或纵向三个或以上相同颜色的宝石会被消除
- **得分规则**：每消除一个宝石得 10 分
- **游戏时长**：60 秒倒计时
- **胜负判定**：时间结束时分数高者获胜

## WebSocket 消息协议

### 客户端 -> 服务器

| 消息类型 | 说明 | 参数 |
|---------|------|------|
| `create_room` | 创建房间 | `nickname` |
| `join_room` | 加入房间 | `roomCode`, `nickname` |
| `random_match` | 随机匹配 | `nickname` |
| `leave_room` | 离开房间 | - |
| `start_game` | 开始游戏 | - |
| `score_update` | 更新分数 | `score` |
| `chat` | 发送聊天消息 | `message` |
| `game_end` | 游戏结束 | `score` |

### 服务器 -> 客户端

| 消息类型 | 说明 | 参数 |
|---------|------|------|
| `room_created` | 房间创建成功 | `roomCode`, `playerName`, `isHost` |
| `room_joined` | 加入房间成功 | `roomCode`, `playerName`, `opponentName`, `isHost` |
| `player_joined` | 有玩家加入 | `playerName` |
| `match_found` | 匹配成功 | `roomCode`, `opponentName`, `isHost` |
| `matching` | 匹配中 | `message` |
| `player_left` | 玩家离开 | `playerName` |
| `game_start` | 游戏开始 | `players` |
| `score_update` | 分数更新 | `playerName`, `score` |
| `chat` | 聊天消息 | `sender`, `message`, `timestamp` |
| `game_end` | 游戏结束 | `scores` |
| `error` | 错误消息 | `message` |

## 部署建议

### 本地部署
直接按照安装步骤运行即可。

### 生产环境部署
1. 使用 PM2 管理进程
2. 配置反向代理（Nginx）
3. 启用 HTTPS（使用 Let's Encrypt）
4. 配置防火墙规则

### 云平台部署
支持部署到以下平台：
- Heroku
- AWS EC2
- Google Cloud Platform
- Azure
- Digital Ocean

## 性能优化

- WebSocket 连接池管理
- 房间自动清理（30 分钟未活动）
- 心跳检测和自动重连
- 消息队列缓冲

## 未来扩展

- [ ] 添加道具系统
- [ ] 排行榜功能
- [ ] 好友系统
- [ ] 多人房间（支持 4 人对战）
- [ ] 观战模式
- [ ] 录像回放
- [ ] 成就系统
- [ ] 皮肤商城

## 许可证

MIT License

## 贡献

欢迎提交 Issue 和 Pull Request！

## 联系方式

如有问题或建议，请通过 GitHub Issues 联系。
